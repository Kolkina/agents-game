﻿using UnityEngine;
using System.Collections;

public abstract class Action : MonoBehaviour {

	abstract public void Activate();
	
}
